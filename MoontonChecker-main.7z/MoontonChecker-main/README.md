# MOONTON ACCOUNT CHECKER

Can only be run in python3

## Install
```
pkg update && pkg upgrade
pkg install python git
pip install requests futures bs4
git clone https://github.com/fahmicog/MoontonChecker
cd MoontonChecker
python moonton.py
```
